# JavaScript Drum Kit 

A simple interactive drum kit built with vanilla JavaScript, HTML, and CSS. 

## 🚀 Getting Started

1. Clone or download this project
2. Open `index.html` in your web browser 
3. Start playing! 🎶